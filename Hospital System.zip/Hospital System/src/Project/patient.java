/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Project;

/**
 *
 * @author salah
 */
public class patient extends person{
         String department,dicease;
   

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDicease() {
        return dicease;
    }

    public void setDicease(String dicease) {
        this.dicease = dicease;
    }

   
}
